<?php defined('SYSPATH') or die('No direct script access.');?>

<div class="panel panel-default">
    <div class="panel-body">
        <?=$phpinfo?>
    </div>
</div>