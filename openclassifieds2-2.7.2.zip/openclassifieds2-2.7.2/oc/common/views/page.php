<?php defined('SYSPATH') or die('No direct script access.');?>

<div class="page-header">
    <h1><?=$page->title?></h1>
</div>

<div class="text-description">
	<?=Text::bb2html($page->description,TRUE,FALSE)?>
</div><!-- /well -->
