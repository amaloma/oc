<?php defined('SYSPATH') or die('No direct script access.');?>
	
<div class="page-header">
	<h1><?=__('Login')?></h1>
</div>

	<?=View::factory('pages/auth/login-form')?>
