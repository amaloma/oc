<div class="checkbox">
    <label>
        <?php echo Form::checkbox($field['field_name'], '1', (bool)$field['value']); ?>
        &nbsp;
    </label>
</div>