<?php echo Form::textarea($field['field_name'], $field['value'], $field['attributes']); ?>
