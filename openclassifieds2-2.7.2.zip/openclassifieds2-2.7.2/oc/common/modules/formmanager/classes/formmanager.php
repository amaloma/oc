<?php defined('SYSPATH') or die('No direct script access.');

abstract class FormManager extends FormManager_Core_FormManager {}