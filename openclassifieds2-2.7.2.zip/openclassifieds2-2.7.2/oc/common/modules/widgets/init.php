<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * initiating the Widgets modules
 *
 */


/**
 * placeholders that exists in the default module
 * @var array
 */
widgets::$default_placeholders	 = array('sidebar');