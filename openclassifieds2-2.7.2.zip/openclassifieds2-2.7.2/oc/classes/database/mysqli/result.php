<?php defined('SYSPATH') OR die('No direct script access.');

class Database_MySQLi_Result extends OC_Database_MySQLi_Result {}