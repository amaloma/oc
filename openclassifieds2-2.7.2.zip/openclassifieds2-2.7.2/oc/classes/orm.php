<?php defined('SYSPATH') OR die('No direct script access.');

class ORM extends OC_ORM {}
